# ⚙️ Bug fixes and Improvements

- Revised sing-box DNS syntax due to recent changes
- Validate panel remote DNS entry
- Updated docs
- Bug fix, NPM package removed #1045
